package data;
import java.sql.ResultSet;


import org.neo4j.jdbc.Neo4jConnection;
import org.neo4j.jdbc.Neo4jStatement;

import neorest.neorest;


public class Node {
	String qry,chkqry;
	ResultSet rs;
	public String CreateNode(String prop[],String value[])// args property and each value
	{   int j=-100;
		neorest ne=new neorest();
		Neo4jConnection con=ne.getconnection();
		Neo4jStatement st=new Neo4jStatement(con);
				
		if(prop.length==value.length)
		{	qry="create n={";
			for(int i=0;i<prop.length;i++)
			{	if(i!=prop.length-1)
				qry+=prop[i]+" : '"+value[i]+"',";
			else if(i==prop.length-1)
				qry+=prop[i]+" : '"+value[i]+"'}";
				
				
			}
			
			System.out.println(qry);
		}//query build here
		
		try
		{ 
			chkqry="start n=node(*) where n.Name='"+value[1]+"' return n.Name";
			rs=st.executeQuery(chkqry);
			if(!rs.next()) //if node doesnot exist
			{
		 j=st.executeUpdate(qry);
			System.out.println(j);
			if(j==0)// if node made
				return "succees";
			else // if not made
				return "failure";
			}
		
			 			
		
		else // if node already exist
			return "Node already exist";
		}catch(Exception e)
		{
		e.printStackTrace();
		}
		return "";
	}
	
	
	
	void CreateRelationship(String relation,String startnode,String lastnode)
	{
		int i=-100;
		neorest ne=new neorest();
		Neo4jConnection con=ne.getconnection();
		Neo4jStatement st=new Neo4jStatement(con);
		try
		{
		chkqry="start s=node(*), l=node(*) match s-[r:"+relation+"]->l where s.Name='"+startnode+"' and l.Name='"+lastnode+"' return r";
		rs=st.executeQuery(chkqry);
		if(!rs.next())
		{
		qry= "start s=node(*),l=node(*) create s-[r:"+relation+"]->l where s.Name='"+startnode+"' and l.Name='"+lastnode+"' return r";
		
	
		
		rs=st.executeQuery(qry);	
			if(rs.next())
				System.out.println("relation created");
			else 
				System.out.println("relation not created");
		}
		else 
			System.out.println("Relation exist");
		}catch(Exception e)
		{e.printStackTrace();}
	
	}
	
public static void main(String a[])
{  	Node n=new Node();
//String []prop={"Name","code"};
//String[]value={"Uttarakhand","Uttarakhand_class"};
//System.out.println(n.CreateNode(prop, value));

String[] prop=new String[2];
String[] value=new String[2];
prop[0]="code";
prop[1]="Name";

value[0]="Uttarakhand_class";
value[1]="Uttarakhand";
n.CreateNode(prop,value);

value[0]="Dehradun_class";
value[1]="Dehradun";
n.CreateNode(prop,value);

value[0]="Haridwar_class";
value[1]="Haridwar";
n.CreateNode(prop,value);

value[0]="Rishikesh_class";
value[1]="Rishikesh";
n.CreateNode(prop,value);

value[0]="Lansdowne_class";
value[1]="Lansdowne";
n.CreateNode(prop,value);

value[0]="Dhanaulti_class";
value[1]="Dhanaulti";
n.CreateNode(prop,value);

value[0]="Chamba_class";
value[1]="Chamba";
n.CreateNode(prop,value);

value[0]="Auli_class";
value[1]="Auli";
n.CreateNode(prop,value);

value[0]="Pauri_class";
value[1]="Pauri";
n.CreateNode(prop,value);

value[0]="Chopta_class";
value[1]="Chopta";
n.CreateNode(prop,value);

value[0]="Chakrata_class";
value[1]="Chakrata";
n.CreateNode(prop,value);

value[0]="Mussoorie_class";
value[1]="Mussoorie";
n.CreateNode(prop,value);

value[0]="Nainital_class";
value[1]="Nainital";
n.CreateNode(prop,value);

value[0]="Chamoli_class";
value[1]="Chamoli";
n.CreateNode(prop,value);

value[0]="Uttarkashi_class";
value[1]="Uttarkashi";
n.CreateNode(prop,value);

value[0]="Guptkashi_class";
value[1]="Guptkashi";
n.CreateNode(prop,value);

value[0]="Garhwal Himalaya_class";
value[1]="Garhwal Himalaya";
n.CreateNode(prop,value);


n.CreateRelationship("hasDestination", "Uttarakhand","Dehradun");
n.CreateRelationship("hasDestination", "Uttarakhand","Uttarkashi");
n.CreateRelationship("hasDestination", "Uttarakhand","Guptkashi");
n.CreateRelationship("hasDestination", "Uttarakhand","Garhwal Himalaya");
n.CreateRelationship("hasDestination", "Uttarakhand","Nainital");
n.CreateRelationship("hasDestination", "Uttarakhand","Chamoli");
n.CreateRelationship("hasDestination", "Uttarakhand","Mussoorie");
n.CreateRelationship("hasDestination", "Uttarakhand","Haridwar");
n.CreateRelationship("hasDestination", "Uttarakhand","Rishikesh");
n.CreateRelationship("hasDestination", "Uttarakhand","Lansdowne");
n.CreateRelationship("hasDestination", "Uttarakhand","Dhanaulti");
n.CreateRelationship("hasDestination", "Uttarakhand","Chamba");
n.CreateRelationship("hasDestination", "Uttarakhand","Auli");
n.CreateRelationship("hasDestination", "Uttarakhand","Chopta");
n.CreateRelationship("hasDestination", "Uttarakhand","Chakrata");
n.CreateRelationship("hasDestination", "Uttarakhand","Pauri");

}
}
