package data;
import java.io.BufferedReader;

import neorest.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public class parserWildLife {
	public static void main(String args[]) {
		String str1 = null;
		String[] value = new String[8];
		String[] prop = new String[8];
		prop[0] = "Ref_Id";
		prop[1] = "Name";
		prop[2] = "Node_Type";
		prop[3]="Location";
		prop[4]="BestTimetoVisit";
		prop[5]="Attration";
		prop[6]="Area";
		prop[7]="Climate";
						
		int i,j;
		Node n = new Node();
		try {
			File f=new File("WildLife.csv");
					
			FileReader fw = new FileReader(f);
			BufferedReader bw = new BufferedReader(fw);
			j=0;
			while ((str1=bw.readLine())!=null) {
							
				System.out.println(str1);
				value = str1.split(",");
				String [] val=new String[8];
				for(i=0;i<8;i++)
					val[i]=value[i];
				n.CreateNode(prop, val);
				
				j++;
					
			}
			System.out.println(j);
		
			FileReader fr=new FileReader(f);
			BufferedReader br=new BufferedReader(fr);
			while ((str1=br.readLine())!=null) {
				value=str1.split(",");
				System.out.println(value[8]+"   "+value[1]);
			n.CreateRelationship("hasAccomodation",value[8],value[1]);
				
			}
			
			
			
			
		} catch (IOException ex) {
				ex.printStackTrace();
		}

		// n.CreateNode(prop,str);

	}
}
