package data;
import java.io.BufferedReader;

import neorest.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public class parserHotel {
	public static void main(String args[]) {
		String str1 = null;
		String[] value = new String[7];
		String[] prop = new String[7];
		prop[0] = "Ref_Id";
		prop[1] = "Name";
		prop[2] = "Node_Type";
		prop[3]="Address";
		prop[4]="Starting_Rate";
		prop[5]="Rating";
		prop[6]="Total_rooms";
						
		int i,j;
		Node n = new Node();
		try {
			File f=new File("Hotel.csv");
					
			FileReader fw = new FileReader(f);
			BufferedReader bw = new BufferedReader(fw);
			j=0;
			while ((str1=bw.readLine())!=null) {
							
				System.out.println(str1);
				value = str1.split(",");
				String [] val=new String[7];
				for(i=0;i<7;i++)
					val[i]=value[i];
				n.CreateNode(prop, val);
				
				j++;
					
			}
			System.out.println(j);
		
			FileReader fr=new FileReader(f);
			BufferedReader br=new BufferedReader(fr);
			while ((str1=br.readLine())!=null) {
				value=str1.split(",");
				System.out.println(value[7]+"   "+value[1]);
			n.CreateRelationship("hasAccomodation",value[7],value[1]);
				
			}
			
			
			
			
		} catch (IOException ex) {
				ex.printStackTrace();
		}

		// n.CreateNode(prop,str);

	}
}
